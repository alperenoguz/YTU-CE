package alperenoguzdemir;

public interface IVieawable {
	//Burada ne istedildi�ini anlamad�m.
	public String toString();
}
