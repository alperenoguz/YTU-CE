package alperenoguzdemir;

import java.io.IOException;

public class ApartmentException extends IOException{
	private static final long serialVersionUID = 1L;
	public ApartmentException(String message) {
		super(message);
	}
}
