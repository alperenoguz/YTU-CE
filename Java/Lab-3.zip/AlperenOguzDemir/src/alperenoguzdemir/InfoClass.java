package alperenoguzdemir;

import java.util.ArrayList;
import java.util.List;

public class InfoClass {
	public static <T> void getObjectInfo(T obj){
		System.out.println(obj.toString());
	}

	public static <E> void getListInfo(List<E> per_list) {
		// TODO Auto-generated method stub
		for(E obj: per_list) {
			System.out.println(obj.toString());
		}
	}
}
