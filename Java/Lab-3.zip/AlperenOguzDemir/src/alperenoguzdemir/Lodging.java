package alperenoguzdemir;

import java.util.*;

public class Lodging {
	private static int counter=0;
	private HashMap<Personnel,Apartment> hm= new HashMap<>();
	private List<Personnel> p_list = new ArrayList<>();
	private List<Apartment> a_list = new LinkedList<>();
	public void placement(ArrayList<Personnel> per_list, LinkedList<Apartment> daire_list) {
		// TODO Auto-generated method stub
		this.p_list=per_list;
		this.a_list=daire_list;
		for(Apartment ap : daire_list) {
			hm.put(per_list.get(counter), ap);
			counter++;
		}
	}
	public void placement(Apartment apartment) {
		if(p_list.size()>counter) {
			hm.put(p_list.get(counter), apartment);
			System.out.println("P_Id:"+p_list.get(counter).getId()+" was placed in Aprtmnt_Id: 5");
			counter++;
		}
	}
	public void mapPrint() {
		// TODO Auto-generated method stub
		for(Personnel p : hm.keySet()) {
			System.out.println("P_Id:"+p.getId() + " personel lives in -> Apartment " + hm.get(p).getId());
		}
		if(hm.isEmpty()) {
			System.out.println("No one living in the lodging");
		}
	}
	public void returnApartment(Personnel p) {
		// TODO Auto-generated method stub
		if(hm.get(p)==null) {
			System.out.println(p.getId()+" "+p.getName()+" has already returned the daire.");
		}
		else if(p_list.size()>counter) {
			Apartment ap=hm.get(p);
			hm.remove(p);
			System.out.println("P_Id:"+p.getId()+" personel returned the Aprtmnt_Id: "+ap.getId() + " and new personnel was placed in it");
			hm.put(p_list.get(counter), ap);
			counter++;
		}
		else {
			Apartment ap=hm.get(p);
			hm.remove(p);
			System.out.println("Aprtmnt_Id:"+ap.getId()+" has been returned, however, "
					+ "no placement was made because there was no other staff waiting in line.");
			}
	}
	public void newApartment() throws ApartmentException {
		// TODO Auto-generated method stub
		Scanner scan= new Scanner(System.in);
		int id;
		String type;
		System.out.println("Enter apartment id:");
		id=scan.nextInt();
		System.out.println("Enter type:");
		scan.nextLine();
		type=scan.nextLine();
		for(Apartment ap : a_list) {
			if(ap.getId()==id) {
				throw new ApartmentException("Lodging has this apartment!");
			}
		}
		Apartment ap=new Apartment(id,type);
		a_list.add(ap);
		System.out.println("New apartment added.");
		placement(ap);
		
	}
}
