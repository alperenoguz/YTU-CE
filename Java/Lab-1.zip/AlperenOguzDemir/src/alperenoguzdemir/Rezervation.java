package alperenoguzdemir;

public class Rezervation {
	private static int counter=20230001;
	private int rezervationID;
	private Hotel hotel;
	private int roomNumber;
	private int day;
	public Rezervation(Hotel hotel, int roomNumber, int day) {
		super();
		this.hotel = hotel;
		this.roomNumber = roomNumber;
		this.day = day;
		rezervationID=counter++;
	}
	public double calculatePayment() {
		for(Room r: hotel.getRooms()) {
			if(r.getRoomNumber()==roomNumber) {
				return (double)day*r.getPrice();
			}
		}
		return 0.0;
	}
	public int getRezervationID() {
		return rezervationID;
	}
	public void setRezervationID(int rezervationID) {
		this.rezervationID = rezervationID;
	}
	public Hotel getHotel() {
		return hotel;
	}
	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
	public int getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	@Override
	public String toString() {
		return "Rezervation [rezID=" + rezervationID + ", hotel=" + hotel.toString() + ", roomNumber=" + roomNumber
				+ ", day=" + day + "]";
	}
	
}
