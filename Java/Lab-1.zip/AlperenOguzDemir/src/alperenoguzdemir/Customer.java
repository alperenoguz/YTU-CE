package alperenoguzdemir;
import java.util.ArrayList;
public class Customer {
	private String name;
	private int identityID;
	ArrayList<Rezervation> rezervations= new ArrayList<>();
	public Customer(String name, int identityID) {
		// TODO Auto-generated constructor stub
		this.name=name;
		this.identityID=identityID;
	}

	public void makeRezervation(Hotel hotel, String roomType, int day) {
		// TODO Auto-generated method stub
		boolean c=true;
		boolean made=false;
		for(int i=0;i<4;i++) {
			if(c) {
				if(hotel.getRooms()[i].getRoomType().compareTo(roomType)==0 && hotel.getRooms()[i].isAvailable()) {
					rezervations.add(new Rezervation(hotel,hotel.getRooms()[i].getRoomNumber(),day));
					hotel.getRooms()[i].setAvailable(false);
					c=false;
					made=true;
				}
				
			}

		}
		if(made==false) {
			System.out.println("Sectiginiz oda tipi icin musaitlik bulunamadi.");
		}
	}

	public void listCustomerRezervations() {
		// TODO Auto-generated method stub
		for(Rezervation r : rezervations) {
			System.out.println(r.toString());
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getIdentityID() {
		return identityID;
	}

	public void setIdentityID(int identityID) {
		this.identityID = identityID;
	}

	public ArrayList<Rezervation> getRezervations() {
		return rezervations;
	}

	public void setRezervations(ArrayList<Rezervation> rezervations) {
		this.rezervations = rezervations;
	}

	public void getInvoice(int rezervationID) {
		for(Rezervation r : rezervations) {
			if(rezervationID==r.getRezervationID()) {
				
				System.out.println(r.getDay() + " gunluk odeme tutari: " + r.calculatePayment());
			}
		}
		
	}

}
