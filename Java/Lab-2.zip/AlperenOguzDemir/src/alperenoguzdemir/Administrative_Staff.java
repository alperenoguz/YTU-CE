package alperenoguzdemir;

import java.util.ArrayList;

public class Administrative_Staff extends Staff{
	public Administrative_Staff(int staff_id, String name, String web) {
		super(staff_id,name,web);
	}

	public void print_staff_information() {
		// TODO Auto-generated method stub
		System.out.println("	Name: " + getName() + ", web: " + getWeb());
	}

	public void add_commission(Department d, Commission com1) {
		// TODO Auto-generated method stub
		d.getCommissions().add(com1);
	}

	public void add_academic_staff(Department d, Academic_Staff staff1) {
		// TODO Auto-generated method stub
		d.getAcademic_staffs().add(staff1);
	}

	public void add_staff_to_commission(Department d, int i, String string) {
		// TODO Auto-generated method stub
		for(Academic_Staff staff: d.getAcademic_staffs()) {
			if(staff.getStaff_id()==i) {
				staff.setCom_id(d.get_commission(string).getCommission_id());
			}
		}
	}

	public void print_commission_information(Department d) {
		// TODO Auto-generated method stub
		int i=1;
		for(Commission commission: d.getCommissions() ) {
			System.out.println("	"+i +". Commission: " + commission.getName());
			int j=1;
			for(Academic_Staff staff: d.getAcademic_staffs()) {
				if(staff.getCom_id()==commission.getCommission_id()) {
					System.out.println("		"+j+". Academic Personal: "+staff.getName());
					j++;
				}
			}
			if(j==1) {
				System.out.println("		There is no one in this commision.");
			}
			i++;
		}
	}

	public void get_academic_staffs(Department d) {
		// TODO Auto-generated method stub
		for(Academic_Staff staff: d.getAcademic_staffs()) {
			System.out.println(staff.toString());
			System.out.println(staff.getName() + " Research Areas:");
			for(String res: staff.getResearch_areas()) {
				System.out.println(res);
			}
			System.out.println();
		}
	}
	
}
