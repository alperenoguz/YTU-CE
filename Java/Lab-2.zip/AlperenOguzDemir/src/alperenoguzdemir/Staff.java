package alperenoguzdemir;

public abstract class Staff {
	private String mail;
	private String name;
	private int staff_id;
	private String web;
	public Staff(int staff_id, String name, String web) {
		this.staff_id=staff_id;
		this.name=name;
		this.web=web;
	}
	public Staff(int staff_id, String name, String web, String mail) {
		this.staff_id=staff_id;
		this.name=name;
		this.mail=mail;
		this.web=web;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getWeb() {
		return web;
	}
	public void setWeb(String web) {
		this.web = web;
	}
	public int getStaff_id() {
		return staff_id;
	}
	
}
