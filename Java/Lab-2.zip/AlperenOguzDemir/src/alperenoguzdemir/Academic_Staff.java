package alperenoguzdemir;

import java.util.ArrayList;

public class Academic_Staff extends Staff{
//name web
	private int com_id;
	private String office;
	private ArrayList<String> research_areas= new ArrayList<>();
	public Academic_Staff(int staff_id, String name, String web) {
		super(staff_id,name,web);
	}
	public Academic_Staff(int staff_id, String name, String web,String mail, String office) {
		super(staff_id,name,web,mail);
		this.office=office;
	}
	public int getCom_id() {
		return com_id;
	}
	public void setCom_id(int com_id) {
		this.com_id = com_id;
	}
	public String getOffice() {
		return office;
	}
	public void setOffice(String office) {
		this.office = office;
	}
	public ArrayList<String> getResearch_areas() {
		return research_areas;
	}
	public void add_research(String string) {
		// TODO Auto-generated method stub
		research_areas.add(string);
	}
	public void delete_research(int i) {
		// TODO Auto-generated method stub
		research_areas.remove(i);
	}
	public void delete_research(String string) {
		// TODO Auto-generated method stub
		research_areas.remove(string);
	}
	public String toString() {
		return "Name: " + getName() + ", " + "web: " + getWeb() +", office_no: " + office;
	}
}
