package alperenoguzdemir;
import java.util.*;
public class Department {
	private ArrayList<Academic_Staff> academic_staffs= new ArrayList<>(); 
	private ArrayList<Commission> commissions= new ArrayList<>();
	private String history;
	private String mission_and_vision;
	private String name;
	public Department(String department_name, String department_history, String mission_and_vision) {
		// TODO Auto-generated constructor stub
		name=department_name;
		history=department_history;
		this.mission_and_vision=mission_and_vision;
	}
	public ArrayList<Academic_Staff> getAcademic_staffs() {
		return academic_staffs;
	}
	public void setAcademic_staffs(ArrayList<Academic_Staff> academic_staffs) {
		this.academic_staffs = academic_staffs;
	}
	public ArrayList<Commission> getCommissions() {
		return commissions;
	}
	public Commission get_commission(String name) {
		for(Commission com : commissions) {
			if(com.getName().equals(name)==true) {
				return com;
			}
		}
		return null;
	}
	public void setCommissions(ArrayList<Commission> commissions) {
		this.commissions = commissions;
	}
	public String getHistory() {
		return history;
	}
	public void setHistory(String history) {
		this.history = history;
	}
	public String getMission_and_vision() {
		return mission_and_vision;
	}
	public void setMission_and_vision(String mission_and_vision) {
		this.mission_and_vision = mission_and_vision;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
