package GUI;
import java.awt.EventQueue;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import userClasses.Alistirma;
import userClasses.Child;

import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ChildGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2544977495550027297L;
	private JPanel contentPane;
	static Child c;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChildGUI frame = new ChildGUI(c);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public static ArrayList<Alistirma> loadAlistirma(String filename){
		ArrayList<Alistirma> als= new ArrayList<>();
		try {
			File file= new File(filename);
			if(!file.exists()) {
				file.createNewFile();
			}
			FileInputStream fin;
			fin = new FileInputStream(file);
			ObjectInputStream in= new ObjectInputStream(fin);
			boolean endOfFile = false;
			while (!endOfFile) {
			    try {
			    	Object obj = in.readObject();
			    	if(obj instanceof Alistirma) {
			    		System.out.println("ok");
				    	Alistirma alistirma = (Alistirma) obj;
				        als.add(alistirma);
			    	}


			    } catch (EOFException e) {
			        endOfFile = true;
			    }
			}
			in.close();
			fin.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return als;
	}
	/**
	 * Create the frame.
	 */
	public ChildGUI(Child c) {
		
		ArrayList<Alistirma> als= loadAlistirma("alistirmalar.txt");
	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		DefaultListModel<String> listModel = new DefaultListModel<>();
		for (Alistirma al : als) {
			listModel.addElement(al.getName());
		}
		
		
		JList<String> list = new JList<>(listModel);
		list.setBounds(10, 10, 220, 201);
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); //listede sadece 1 tane eleman�n se�ilebilmesini sa�lama
		contentPane.add(list);
		
		JButton btnNewButton = new JButton("Al\u0131\u015Ft\u0131rmaya Ba\u015Fla");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(list.getSelectedIndex()!=-1) { //butona bas�ld���nda e�er listede se�ili bir al��t�rma varsa o al��t�rmaya ba�lama
					ChildAl algui = new ChildAl(c,als.get(list.getSelectedIndex())); //�ocuk class� ile birlikte Alistirma class� yollan�yor ilerde kaydetmek i�in
					algui.setVisible(true);
					dispose();
				}
			}
		});
		btnNewButton.setBounds(257, 78, 137, 73);
		contentPane.add(btnNewButton);
	}
}
