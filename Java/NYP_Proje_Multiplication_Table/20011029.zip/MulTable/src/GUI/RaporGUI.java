package GUI;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import userClasses.Child;

import javax.swing.BoxLayout;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;

import java.io.*;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class RaporGUI extends JFrame {
	private static final long serialVersionUID = -965980564039270563L;
	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	public static UsersSerialized loadUsers(String filename) { //Kullan�c�lar�n dosyadan okunmas�
		UsersSerialized users=null;
		try {
			FileInputStream fin;
			fin = new FileInputStream(filename);
			ObjectInputStream in= new ObjectInputStream(fin);
			users = (UsersSerialized) in.readObject();
			in.close();
			fin.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return users;
	}
	public static ArrayList<Skorbilgileri> loadSkors(String filename){ //Skorlar�n dosyadan okunmas�
		FileInputStream fin;
		ArrayList<Skorbilgileri> skors= new ArrayList<>();
		try {
			fin = new FileInputStream(filename);
			ObjectInputStream in= new ObjectInputStream(fin);
			boolean endOfFile = false;
			while (!endOfFile) {
			    try {
			    	Object obj = in.readObject();
			    	if(obj instanceof Skorbilgileri) {
				    	Skorbilgileri skor = (Skorbilgileri) obj;
				        skors.add(skor);
			    	}


			    } catch (EOFException e1) {
			        endOfFile = true; // Set flag to indicate end of file
			    }
			}
			in.close();
			fin.close();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		return skors;
	}
	private UsersSerialized users= loadUsers("users.txt");
	private ArrayList<Skorbilgileri> skors= loadSkors("skorbilgileri.txt");

	public static void export(JTable table2, File file) { // Tablonun excel dosyas� olarak kaydedilmesi
		// TODO Auto-generated method stub
	    try
	    {
	      TableModel m = table2.getModel();
	      FileWriter fw = new FileWriter(file);
	      for(int i = 0; i < m.getColumnCount(); i++){
	        fw.write(m.getColumnName(i) + "\t");
	      }
	      fw.write("\n");
	      for(int i=0; i < m.getRowCount(); i++) {
	        for(int j=0; j < m.getColumnCount(); j++) {
	          fw.write(m.getValueAt(i,j).toString()+"\t");
	        }
	        fw.write("\n");
	      }
	      fw.close();
	    }
	    catch(IOException e){ System.out.println(e); }
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RaporGUI frame = new RaporGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RaporGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 881, 459);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 53, 192, 347);
		contentPane.add(panel_1);
		panel_1.setLayout(new BoxLayout(panel_1, BoxLayout.X_AXIS));
		
		DefaultTableModel model = new DefaultTableModel(new Object[]{"Kullan�c� ad�", "�ifre"}, 0);
		for (Child c : users.getChildren()) {
			model.addRow(new Object[] {c.getUsername(), c.getPassword()});
		}
		
		table = new JTable(model);
		table.setEnabled(false);
		JScrollPane spane= new JScrollPane(table, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		panel_1.add(spane);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(212, 53, 645, 347);
		contentPane.add(panel_2);
		panel_2.setLayout(new BoxLayout(panel_2, BoxLayout.X_AXIS));
		
		// Tablo modeli i�in ba�l�klar�n ve de�erlerinin girilmesi. 
		DefaultTableModel model2 = new DefaultTableModel(new Object[] {"��renci",
																	   "Al��t�rma",
																	   "Ba�lang�� Saati",
																	   "Bitirme S�resi",
																	   "Soru Ba�� Bit. S�resi",
																	   "Do�ru Cevaplar",
																	   "Yanl�� Cevaplar",
																	   "H�z Skoru",
																	   "Do�ruluk Skoru",
																	   "Ger�ek Skor"},0);
		for (Skorbilgileri skor: skors) {
			model2.addRow(new Object[] {skor.c.getUsername(), 
										skor.al.getName(),
										skor.baslangic,
										skor.bitirmeSuresi,
										skor.sorubasi_bit.toString(),
										skor.dogru.toString(),
										skor.yanlis.toString(),
										skor.speed_score,
										skor.dogru_score,
										skor.true_score});
		}
		
		table_1 = new JTable(model2);
		table_1.setEnabled(false);
		JScrollPane spane2= new JScrollPane(table_1, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		panel_2.add(spane2);
		
		JButton btnNewButton = new JButton("G\u00FCnceleri Excele Yazd\u0131r"); //G�nceleri excel olarak yazd�rmak i�in buton
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		           JFileChooser fchoose = new JFileChooser();
		           int option = fchoose.showSaveDialog(null); //Kaydetme aray�z�n�n g�z�kmesi
		           if(option == JFileChooser.APPROVE_OPTION){ //Kaydetme i�lemi i�in butona t�klanmas�
			             String name = fchoose.getSelectedFile().getName(); //Kaydedilecek dosyan�n ismi
			             String path = fchoose.getSelectedFile().getParentFile().getPath(); //Kaydedilecek dosyan�n yolu
			             String file = path + "\\" + name + ".xls"; // Kaydedilecek dosyan�n ismi ile birlikte yolu
			             export(table_1, new File(file)); // Tablonun dosyaya kaydedilmesi
		           }
			}
		});
		btnNewButton.setBounds(212, 22, 375, 21);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u00D6\u011Frencileri Excele Yazd\u0131r"); //��rencileri excel olarak yazd�rmak i�in buton
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		           JFileChooser fchoose = new JFileChooser();
		           int option = fchoose.showSaveDialog(null);
		           if(option == JFileChooser.APPROVE_OPTION){
			             String name = fchoose.getSelectedFile().getName(); 
			             String path = fchoose.getSelectedFile().getParentFile().getPath();
			             String file = path + "\\" + name + ".xls"; 
			             export(table, new File(file));
		           }
			}
		});
		btnNewButton_1.setBounds(10, 22, 192, 21);
		contentPane.add(btnNewButton_1);

	}
}
