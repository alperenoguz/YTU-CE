package GUI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import userClasses.Child;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginGUI extends JFrame {
	private static final long serialVersionUID = 8655068416200456456L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	static UsersSerialized users;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginGUI frame = new LoginGUI(users);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginGUI(UsersSerialized users) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 525, 296);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Kullan\u0131c\u0131 Ad\u0131");
		lblNewLabel.setBounds(91, 58, 156, 37);
		contentPane.add(lblNewLabel);

		textField = new JTextField();
		textField.setBounds(203, 58, 156, 37);
		contentPane.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBounds(203, 105, 156, 31);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("\u015Eifre");
		lblNewLabel_1.setBounds(91, 105, 156, 31);
		contentPane.add(lblNewLabel_1);

		JButton btnNewButton = new JButton("Giri\u015F Yap"); //Giri� yapma butonu kullan�c� ad� ve �ifre kullan�c�lardan herhangi birine denkse giri� yap�yor.
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String username = textField.getText(); // textField'dan kullan�c� ad� ve �ifre verisi al�n�yor
				String password = textField_1.getText();
				
				if (username.equals(users.getParent().getUsername())
						&& password.equals(users.getParent().getPassword())) {
					ParentGUI pgui = new ParentGUI(users.getParent()); //Girilen kullan�c� ad� Parent oldu�u i�in ParentGUI'sine ge�i� yap�l�yor.
					pgui.setVisible(true);
					dispose();
				} else {
					for (Child c : users.getChildren()) { //Kullan�c� listesindeki t�m �ocuklar�n kullan�c� ad� ve �ifresi
						if (c.getUsername().equals(username) && c.getPassword().equals(password)) {
							ChildGUI cgui= new ChildGUI(c); //Girilen kullan�c� ad� �ocuklardan birinin oldu�u i�in ChildGUI'sine ge�i� yap�l�yor.
							cgui.setVisible(true);
							dispose();
						}
					}
				}
			}
		});
		btnNewButton.setBounds(225, 157, 95, 37);
		contentPane.add(btnNewButton);

	}
}
