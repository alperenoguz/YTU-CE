package GUI;

import java.io.*;
import java.util.*;

import userClasses.Child;
import userClasses.Parent;

class UsersSerialized implements Serializable { // Kullan�c�lar� 1 tane parent ve 1'den fazla �ocuk olacak �ekilde 
												// class olarak tan�mlad�m kaydetme ve okuma kolayl��� olsun diye
	
	private static final long serialVersionUID = 4L;

    private Parent parent;
    private ArrayList<Child> children;
	
    public UsersSerialized(Parent parent, ArrayList<Child> children) {
        this.parent = parent;
        this.children = children;
    }
    public Parent getParent() {
        return parent;
    }
    public ArrayList<Child> getChildren() {
        return children;
    }
}
public class Main {

	public static void saveUsers(UsersSerialized users, String filename) { //Kullan�c�lar� dosyaya kaydetmek i�in fonksiyon
		try {
			File file= new File(filename);
			if(!file.exists()) {
				file.createNewFile();
			}
			FileOutputStream fout = new FileOutputStream(file, false);
			ObjectOutputStream out = new ObjectOutputStream(fout);
			out.writeObject(users);		
			System.out.println("Save succesful");
			
			out.close();
			fout.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	public static UsersSerialized loadUsers(String filename) { //Kullan�c�lar� dosyadan almak i�in fonksiyon
		UsersSerialized users=null;
		try {
			FileInputStream fin;
			fin = new FileInputStream(filename);
			ObjectInputStream in= new ObjectInputStream(fin);
			users = (UsersSerialized) in.readObject();
			System.out.println("Load succesful");
			in.close();
			fin.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return users;
	}

	public static void main(String[] args) {
		/*
		Parent parent = new Parent("admin", "123");
		Child c1 = new Child("ali", "123");
		Child c2 = new Child("ay�e", "123");
		Child c3 = new Child("mehmet", "1234");
		Child c4 = new Child("veli","123");
		ArrayList<Child> children = new ArrayList<>();
		children.add(c1);
		children.add(c2);
		children.add(c3);
		children.add(c4);
		UsersSerialized users = new UsersSerialized(parent, children);
		saveUsers(users,"users.txt"); // E�er users dosyas�n� sildiyseniz �al��t�r�n 
		*/
		//
		UsersSerialized users= loadUsers("users.txt"); //Sildiyseniz bunu �al��t�rmay�n.
		LoginGUI lgui=new LoginGUI(users); //Giri� i�in GUI olu�turma
		lgui.setVisible(true);
	}
}
