package GUI;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.table.*;
public class ChildScoreboard extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4726799800888112077L;
	static ArrayList<Skorbilgileri> skors;
	static Skorbilgileri s;
	private JPanel contentPane;
	private JTable table;
	public static Comparator<Skorbilgileri> comp = new Comparator<>() { //Skora g�re s�ralama yapmak i�in tan�m

		@Override
		public int compare(Skorbilgileri o1, Skorbilgileri o2) {
			// TODO Auto-generated method stub
			int skor1=o1.true_score;
			int skor2=o2.true_score;
			return skor2-skor1;
		}
		
	};
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChildScoreboard frame = new ChildScoreboard(skors,s);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param s 
	 * @param skors 
	 */

	public ChildScoreboard(ArrayList<Skorbilgileri> skors, Skorbilgileri s) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 859, 445);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		String dstr= "Do�ru Cevap Say�s� : "+ s.dogru.size();
		JLabel lblNewLabel = new JLabel(dstr);
		lblNewLabel.setBounds(10, 48, 163, 31);
		contentPane.add(lblNewLabel);
		
		String ystr= "Yanl\u0131\u015F Cevap Say\u0131s\u0131 : "+ s.yanlis.size();
		JLabel lblYanlCevapSays = new JLabel(ystr);
		lblYanlCevapSays.setBounds(10, 89, 163, 31);
		contentPane.add(lblYanlCevapSays);
		
		String spstr = "H\u0131z Skoru : " + s.speed_score;
		JLabel lblHzSkoru = new JLabel(spstr);
		lblHzSkoru.setBounds(10, 130, 163, 31);
		contentPane.add(lblHzSkoru);
		
		String dscorestr="Do\u011Fruluk Skoru : "+ s.dogru_score;
		JLabel lblDorulukSkoru = new JLabel(dscorestr);
		lblDorulukSkoru.setBounds(10, 171, 163, 31);
		contentPane.add(lblDorulukSkoru);
		
		String trscstr= "Do\u011Fruluk/H\u0131z Skoru : " + s.true_score; 
		JLabel lblDorulukhzSkoru = new JLabel(trscstr);
		lblDorulukhzSkoru.setBounds(10, 212, 163, 31);
		contentPane.add(lblDorulukhzSkoru);

		//Y�ksek skora g�re s�rala
		Collections.sort(skors, comp); //Skora g�re s�ralama
		DefaultTableModel model = new DefaultTableModel(new Object[]{"Kullan�c�", "Skor"}, 0);
		for (Skorbilgileri skor : skors) {
			if(skor.al.getName().equals(s.al.getName())) {//Ayn� al��t�rmadaki skorlar� ekleme
				model.addRow(new Object[] {skor.c.getUsername(), skor.true_score});
			}
		}
		
		table = new JTable(model);
		table.setEnabled(false);
		JScrollPane spane= new JScrollPane(table, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		
		JPanel panel = new JPanel();
		panel.setBounds(281, 41, 492, 355);
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		panel.add(spane);
		contentPane.add(panel);
		
		JLabel lblNewLabel_1 = new JLabel("Y\u00FCksek Skor");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(411, 10, 212, 21);
		contentPane.add(lblNewLabel_1);
	}
}
