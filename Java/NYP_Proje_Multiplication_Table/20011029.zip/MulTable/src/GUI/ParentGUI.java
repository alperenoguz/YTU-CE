package GUI;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import userClasses.Parent;
import userClasses.Alistirma;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.BoxLayout;

public class ParentGUI extends JFrame {
	private static final long serialVersionUID = -2938215667004341423L;
	static Parent parent;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	public ArrayList<Alistirma> getAlistirmalar(String filename){ //Al��t�rmalar�n dosyadan �ekilmesi i�in fonksiyon
		ArrayList<Alistirma> als = new ArrayList<>();
		File f=new File(filename);
		FileInputStream fin;
		try {
			fin = new FileInputStream(f);
			ObjectInputStream in = new ObjectInputStream(fin);
		    boolean endOfFile = false;
		    while (!endOfFile) {
		        try {
		            Alistirma al =(Alistirma) in.readObject();
		            als.add(al);
		        } catch (EOFException e) {
		            endOfFile = true; 
		        }
		    }
		    in.close();
		    fin.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return als;
	}
	ArrayList<Alistirma> als = getAlistirmalar("alistirmalar.txt");
	
	
	public void yazveCik(String filename) { //Parent ��k�� yapt���nda elemanlar�n eklenmesi i�in fonksiyon
		try {
			File file = new File(filename);
			if(!file.exists()) {
				file.createNewFile();
			}
			FileOutputStream fout = new FileOutputStream(file, false);
			ObjectOutputStream out = new ObjectOutputStream(fout);
			
			for (Alistirma alg : als) {
				System.out.println(alg.getName());
				out.writeObject(alg);
			}
			out.close();
			fout.close();
			dispose();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ParentGUI frame = new ParentGUI(parent);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ParentGUI(Parent parent) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 714, 428);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		textField = new JTextField();
		textField.setBounds(268, 62, 113, 33);
		contentPane.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBounds(412, 62, 113, 33);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		textField_2 = new JTextField();
		textField_2.setBounds(268, 146, 113, 33);
		contentPane.add(textField_2);
		textField_2.setColumns(10);

		JLabel lblNewLabel = new JLabel("Alt S\u0131n\u0131r");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(268, 21, 113, 31);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\u00DCst S\u0131n\u0131r");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(412, 25, 113, 22);
		contentPane.add(lblNewLabel_1);

		JButton btnNewButton = new JButton("Al\u0131\u015Ft\u0131rma Ekle"); //Al��t�rma ekleme i�lemi bu buton ile ger�ekle�iyor
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name;
				int alt = -5, ust = -5, al_say = -1; // alt : olabilecek en k���k de�er, ust : olabilecek en b�y�k de�er, al_say : Al��t�rma say�s�
				try {
					alt = Integer.parseInt(textField.getText()); //GUI'de girilen bilgileri integera d�n��t�rme
					ust = Integer.parseInt(textField_1.getText());
					al_say = Integer.parseInt(textField_2.getText());
				} catch (NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "Uygun Olmayan Bir De�er Girdiniz", "Hata",
							JOptionPane.ERROR_MESSAGE);
				}
				//Herhangi bir yaz� blo�u bo� ise hata diyalo�u g�steriliyor.
				if (textField.getText().isEmpty() || textField_1.getText().isEmpty() || textField_2.getText().isEmpty() 
						|| textField_3.getText().isEmpty()) { 
					JOptionPane.showMessageDialog(null, "Eksik Bir Bilgi Girdiniz", "Hata", JOptionPane.ERROR_MESSAGE);
				} else {
					if(ust<=alt || al_say<=0) { // e�er girilen de�erler sorunlu ise hata diyalo�u g�steriliyor.
						JOptionPane.showMessageDialog(null, "Uygun Olmayan Bir De�er Girdiniz", "Hata",
								JOptionPane.ERROR_MESSAGE);
					}
					else {
						name = textField_3.getText();
						Alistirma al = new Alistirma(name, alt, ust, al_say);
						als.add(al);
					}

				}
			}
		});
		btnNewButton.setBounds(268, 238, 257, 21);
		contentPane.add(btnNewButton);

		JLabel lblNewLabel_2 = new JLabel("Soru Say\u0131s\u0131");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(268, 112, 98, 24);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Al\u0131\u015Ft\u0131rma \u0130smi");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(412, 112, 113, 24);
		contentPane.add(lblNewLabel_3);

		textField_3 = new JTextField();
		textField_3.setBounds(412, 146, 113, 33);
		contentPane.add(textField_3);
		textField_3.setColumns(10);

		JButton btnNewButton_2 = new JButton("\u00C7\u0131k\u0131\u015F Yap");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				yazveCik("alistirmalar.txt");
			}
		});
		btnNewButton_2.setBounds(400, 343, 290, 22);
		contentPane.add(btnNewButton_2);

		JLabel lblNewLabel_4 = new JLabel(
				"\u00C7\u0131k\u0131\u015F\u0131 buradan yapmazs\u0131n\u0131z yapt\u0131\u011F\u0131n\u0131z de\u011Fi\u015Fiklikler eklenmez.");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4.setBounds(268, 319, 422, 13);
		contentPane.add(lblNewLabel_4);
		
		JButton btnNewButton_3 = new JButton("Raporlar\u0131 g\u00F6ster");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RaporGUI rgui=new RaporGUI(); //Raporlama Ekran�na buradan ge�i� yap�l�yor.
				rgui.setVisible(true);
				dispose();
			}
		});
		btnNewButton_3.setBounds(24, 344, 290, 21);
		contentPane.add(btnNewButton_3);
		
		JPanel panel = new JPanel();
		panel.setBounds(24, 21, 206, 290);
		contentPane.add(panel);
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		
		DefaultListModel<String> model = new DefaultListModel<>(); //Al��t�rmalar�n g�sterilmesi burada ger�ekle�iyor.
		for(Alistirma al: als) {
			model.addElement(al.getName());
		}
		JList <String>list = new JList<>(model);
		JScrollPane sp= new JScrollPane(list);
		panel.add(sp);
	}
}
