package GUI;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.Random;
import java.text.DecimalFormat;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.Timer;
import userClasses.Alistirma;
import userClasses.Child;
import java.io.*;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.time.LocalTime;
import java.awt.event.ActionEvent;
class Skorbilgileri implements Serializable{ //Skor bilgilerinin kaydedildi�i s�n�f
	private static final long serialVersionUID = -8987387539140536298L;
	Child c; //��zen �ocuk
	Alistirma al; //��z�len Al��t�rma
	LocalTime baslangic; // Al��t�rmaya Ba�lang�� zaman�
	int bitirmeSuresi; // Al��t�rman�n toplamda bitirme s�resi saniye olarak
	ArrayList<Integer> sorubasi_bit; // Her soru i�in harcanan zaman 
	ArrayList<int[]> questions; // Sorular
	ArrayList<Integer> dogru; // Do�ru cevaplanan sorular�n indisi
	ArrayList<Integer> yanlis; // Yanl�� cevaplanan sorular�n indisi
	int speed_score; // H�z skoru
	int dogru_score; // Do�ruluk skoru
	int true_score; // Ger�ek skor
	public Skorbilgileri(Child c,Alistirma al,LocalTime baslangic,int bitirmeSuresi,ArrayList<Integer> sorubasi_bit,ArrayList<int[]> questions,ArrayList<Integer> dogru,ArrayList<Integer> yanlis) {
		this.c=c;
		this.al=al;
		this.baslangic=baslangic;
		this.bitirmeSuresi=bitirmeSuresi;
		this.sorubasi_bit=sorubasi_bit;
		this.questions=questions;
		this.dogru=dogru;
		this.yanlis=yanlis;
		this.speed_score=100000/bitirmeSuresi; //H�z skorunun hesab�
		this.dogru_score=(dogru.size()*(1000/questions.size())); // Do�ruluk Skorunun hesab�
		this.true_score=speed_score*dogru_score/100; // H�z ve do�ruluk skorunun �arp�m� ile elde edilen ger�ek skor
	}
}
public class ChildAl extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5547724103643449022L;
	static Child c;
	static Alistirma al;
	private JPanel contentPane;
	private JTextField textField;
	static int counter = 0; // sorular i�in indis 
	static LocalTime startTime = LocalTime.now();
	static int eskibitis=0;
	static int timePassed = 0;
	ArrayList<Integer> sorubit= new ArrayList<>();
	ArrayList<Integer> dogru= new ArrayList<>();
	ArrayList<Integer> yanlis= new ArrayList<>();
	ArrayList<Skorbilgileri> skors= new ArrayList<>();
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChildAl frame = new ChildAl(c,al);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param c 
	 * 
	 * @param al
	 */
	public ChildAl(Child c, Alistirma al) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		ArrayList<int[]> questions = new ArrayList<>();
		Random random = new Random();
		int N = al.getAl_say();
		int a = al.getAlt();
		int b = al.getUst();
		for (int i = 0; i < N; i++) { // sorular�n �retilmesi
			int x = random.nextInt(a, b);
			int y = random.nextInt(a, b);
			int z = x * y;
			int[] question = { x, y, z };
			questions.add(question);

		}
		for (int[] question : questions) {
			System.out.println(question[0] + " * " + question[1] + " = " + question[2]);
		}
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel.setBounds(39, 79, 59, 66);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1.setBounds(177, 79, 59, 66);
		contentPane.add(lblNewLabel_1);

		JLabel lblX = new JLabel("x");
		lblX.setHorizontalAlignment(SwingConstants.CENTER);
		lblX.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblX.setBounds(108, 79, 59, 66);
		contentPane.add(lblX);

		JLabel lblNewLabel_4 = new JLabel("=");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_4.setBounds(246, 79, 59, 66);
		contentPane.add(lblNewLabel_4);

		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
		textField.setBounds(315, 80, 59, 66);
		contentPane.add(textField);
		textField.setColumns(10);

		lblNewLabel.setText(Integer.toString(questions.get(counter)[0]));
		lblNewLabel_1.setText(Integer.toString(questions.get(counter)[1]));

		JLabel lblNewLabel_2 = new JLabel("00:00:00");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(267, 10, 159, 21);
		contentPane.add(lblNewLabel_2);

		Timer timer = new Timer(1000, new ActionListener() { // Aray�ze yans�t�lacak zaman saat dakika saniye olarak formatlan�yor.
			private DecimalFormat formatter = new DecimalFormat("00");

			public void actionPerformed(ActionEvent e) {
				timePassed++;

				int hours = timePassed / 3600;
				int minutes = (timePassed % 3600) / 60;
				int seconds = timePassed % 60;

				lblNewLabel_2.setText(
						formatter.format(hours) + ":" + formatter.format(minutes) + ":" + formatter.format(seconds));

			}
		});
		timer.start();
		JButton btnNewButton = new JButton("Cevapla");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!textField.getText().isBlank()) { //E�er yaz�lan sonu� bo� de�ilse
					
					if (questions.get(counter)[2] == Integer.parseInt(textField.getText())) { //cevab�n do�rulu�unun kontrol�
						sorubit.add(timePassed-eskibitis); //sorunun tamamlanma s�resi
						eskibitis=timePassed;
						dogru.add(counter);
						counter++;
					} else { //yanl��sa
						sorubit.add(timePassed-eskibitis);
						eskibitis=timePassed;
						yanlis.add(counter);
						counter++;
					}
					if (counter >= N) { // t�m sorular tamamlanm��sa
						Skorbilgileri s= new Skorbilgileri(c,al, startTime, timePassed,sorubit, questions, dogru, yanlis);
						File f=new File("skorbilgileri.txt");
						if(!f.exists()) {
							try {
								f.createNewFile();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
						else {
							FileInputStream fin;
							try {
								fin = new FileInputStream(f);
								ObjectInputStream in= new ObjectInputStream(fin);
								boolean endOfFile = false;
								while (!endOfFile) {
								    try {
								    	Object obj = in.readObject();
								    	if(obj instanceof Skorbilgileri) {
								    		System.out.println("ok");
									    	Skorbilgileri skor = (Skorbilgileri) obj;
									        skors.add(skor);
								    	}


								    } catch (EOFException e1) {
								        endOfFile = true; // Set flag to indicate end of file
								    }
								}
								in.close();
								fin.close();
							} catch (Exception e2) {
								// TODO Auto-generated catch block
								e2.printStackTrace();
							}
							
						}
						skors.add(s);
						
						FileOutputStream fout;

						try {
							fout= new FileOutputStream(f,false);
							ObjectOutputStream out;
							out = new ObjectOutputStream(fout);
							for(Skorbilgileri sk : skors) {
								out.writeObject(sk);
							}
							out.close();
							fout.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						ChildScoreboard csGUI=new ChildScoreboard(skors,s); 
						csGUI.setVisible(true);
						dispose();
					} else {
						lblNewLabel.setText(Integer.toString(questions.get(counter)[0]));
						lblNewLabel_1.setText(Integer.toString(questions.get(counter)[1]));
						textField.setText("");
					}
				}


			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton.setBounds(39, 185, 335, 45);
		contentPane.add(btnNewButton);
		
		
		
		
	}
}
