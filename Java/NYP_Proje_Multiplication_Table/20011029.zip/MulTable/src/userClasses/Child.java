package userClasses;

import java.io.Serializable;

public class Child extends User implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3L;

	public Child(String username, String password) {
		super(username, password);
	}

}
