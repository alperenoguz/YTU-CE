package userClasses;

import java.io.Serializable;

public class Alistirma implements Serializable {
	private static final long serialVersionUID = 8L;
	private String name;
	private int alt, ust, al_say;

	public Alistirma(String name, int alt, int ust, int al_say) {
		this.name = name;
		this.alt = alt;
		this.ust = ust;
		this.al_say = al_say;
	}

	public String getName() {
		return name;
	}

	public int getAlt() {
		return alt;
	}

	public int getUst() {
		return ust;
	}

	public int getAl_say() {
		return al_say;
	}

}