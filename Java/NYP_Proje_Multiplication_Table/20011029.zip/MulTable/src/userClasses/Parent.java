package userClasses;

import java.io.Serializable;

public class Parent extends User implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;

	public Parent(String username, String password) {
		super(username, password);
	}
	
}
