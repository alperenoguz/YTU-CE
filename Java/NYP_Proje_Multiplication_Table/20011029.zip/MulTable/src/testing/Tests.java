package testing;
import GUI.ChildGUI;
import GUI.Main;
import GUI.RaporGUI;
import java.io.*;
import java.io.Serializable;
import java.util.ArrayList;
import javax.swing.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import userClasses.Child;
import userClasses.Parent;
class UsersSerialized implements Serializable {
	private static final long serialVersionUID = 4L;

    private Parent parent;
    private ArrayList<Child> children;
	
    public UsersSerialized(Parent parent, ArrayList<Child> children) {
        this.parent = parent;
        this.children = children;
    }
    public Parent getParent() {
        return parent;
    }
    public ArrayList<Child> getChildren() {
        return children;
    }
}
class Tests {

	@Test
	void loadUsersTest() {  //Kullan�c�lar�n bilgilerinin �ekilebilmesinin testi
		Object users=Main.loadUsers("users.txt");
		Assertions.assertNotNull(users);
	}
	@Test 
	void raporExportTest() { //Rapor excel dosyas� �eklinde kaydedilebilmesinin testi
		String[] cols= {"col1","col2"};
		String[][] rows= {
				{"1","2"},
				{"3","4"},
				{"5","6"},
		};
		JTable table=new JTable(rows,cols);
		File file= new File("raporexporttestfile.xls");
		RaporGUI.export(table,file);
		Assertions.assertNotEquals(0,file.length());
		file.delete();
	}
	@Test
	void raporloadSkorsTest() { //Skorlar�n bilgilerinin �ekilebilmesinin testi
		Object skors=RaporGUI.loadSkors("skorbilgileri.txt");
		Assertions.assertNotNull(skors);
	}
	@Test 
	void loadAlistirmalarTest(){ //Al��t�rmalar�n bilgilerinin �ekilebilmesinin testi
		Object alistirmalar = ChildGUI.loadAlistirma("alistirmalar.txt");
		Assertions.assertNotNull(alistirmalar);
	}
}
